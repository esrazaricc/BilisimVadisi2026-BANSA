# Demo Videosu

Final tesliminden önce demo videosunun bağlantısını ve kısa senaryosunu burada paylaşın. Videoda kullanıcı arayüzü, dashboard, chatbot, metin analizi, yapılandırılmış çıktı ve banka karşılaştırması görünmelidir.

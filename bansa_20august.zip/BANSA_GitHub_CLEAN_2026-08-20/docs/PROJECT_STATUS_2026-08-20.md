# BANSA Project Status — 2026-08-20

## Validated

- PostgreSQL financing repository / `bansa` schema
- standard-product dataset for 10 participation banks
- strict common scenario policy: same amount + same maturity
- verified scenario status handling (`verified*`)
- mixed-benchmark leakage guards
- `finance_live_contract.py` tri-state live calculator contract
- Türkiye Emlak Katılım dynamic live adapter
- Türkiye Emlak Katılım dynamic live test at 75,000 TL / 24 months: exact-match contract passed in the development environment
- persistent scenario sync modules for Emlak, Hayat Finans and T.O.M. Katılım

## In progress

- common `compare_financing()` live orchestration service
- additional bank live adapters
- chatbot tool/router layer
- RAG + local LLM integration
- final chatbot UI and hallucination regression tests

## Repository note

Local PostgreSQL contents are intentionally not packaged in this GitHub-clean snapshot. The repository contains schema, migrations and public-source datasets/snapshots. A current database seed/dump should be exported separately before the final competition submission if exact local DB reproducibility is required.

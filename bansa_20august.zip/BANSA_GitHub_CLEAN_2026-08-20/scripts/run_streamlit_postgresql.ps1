$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

$venvPython = Join-Path $projectRoot ".venv\Scripts\python.exe"

if (Test-Path $venvPython) {
    $python = $venvPython
}
else {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if (-not $pythonCommand) {
        throw "Python bulunamadı. Python 3.11+ kurun veya .venv oluşturun."
    }
    $python = $pythonCommand.Source
}

if (-not $env:POSTGRES_DSN) {
    $secure = Read-Host "PostgreSQL postgres parolası" -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)

    try {
        $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
        if ([string]::IsNullOrWhiteSpace($plain)) {
            throw "Parola boş girildi."
        }
        $encoded = [uri]::EscapeDataString($plain)
        $env:POSTGRES_DSN = "postgresql://postgres:$encoded@127.0.0.1:5432/bansa_db"
        Write-Host "PostgreSQL bağlantısı bu oturum için hazırlandı." -ForegroundColor Green
    }
    finally {
        if ($ptr) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
        Remove-Variable secure, ptr, plain, encoded -ErrorAction SilentlyContinue
    }
}

& $python -m streamlit run .\Ana_Sayfa.py

# BANSA – Katılım Bankacılığı Finansman ve Kampanya Analiz Sistemi

BANSA, katılım bankalarının resmî web kaynaklarından kampanya ve finansman verilerini toplayan, normalize eden, kaynak izlenebilirliğiyle saklayan ve Streamlit üzerinden karşılaştıran açık kaynak bir çalışmadır.

Projenin finansman karşılaştırma katmanında PostgreSQL (`bansa` şeması) source-of-truth olarak kullanılır. Sayısal karşılaştırmalar LLM'e yaptırılmaz; tutar, vade, oran, taksit ve geri ödeme gibi alanlar yapısal veri ve doğrulanmış hesaplama sonuçları üzerinden deterministik olarak işlenir. Dil modeli/chatbot katmanı bu güvenilir sonuçların doğal dilde açıklanması için tasarlanmaktadır.

## Güncel durum – 20 Ağustos 2026

- 10 katılım bankasına ait güncel standard-product JSON snapshot'ları `data/standard_products/` altında yer alır.
- Finansman verisi PostgreSQL `bansa` şemasında normalize edilir.
- Finansman karşılaştırmasında **aynı tutar + aynı vade** kuralı uygulanır; farklı benchmark sonuçları birbirine karıştırılmaz.
- Exact scenario filtresi yalnız doğrulanmış (`verified*`) ve birebir tutar/vade eşleşen kayıtları kabul eder.
- `src/finance_live_contract.py` canlı calculator adapterları için `VERIFIED / INELIGIBLE / UNVERIFIED` sözleşmesini uygular.
- `src/finance_live_adapters/emlak_katilim.py` Türkiye Emlak Katılım için dinamik tutar/vade ile çalışan ilk canlı adapterdır.
- Kalıcı scenario doğrulama/sync scriptleri Türkiye Emlak Katılım, Hayat Finans ve T.O.M. Katılım için `scripts/finance_scenarios/` altında bulunur.
- Chatbot ekranı projede bulunmakla birlikte tam agent/RAG + dinamik karşılaştırma entegrasyonu geliştirme aşamasındadır.

> Bu snapshot, GitHub paylaşımı için temizlenmiş kaynak sürümdür. Yerel PostgreSQL veritabanı içeriği ve parolalar repoya dahil edilmez.

## Mimari

```text
Resmî banka web sayfaları / calculator endpointleri
                    │
                    ▼
       Scraping + doğrulama + normalizasyon
                    │
                    ▼
          PostgreSQL / bansa şeması
                    │
          ┌─────────┴─────────┐
          ▼                   ▼
  Deterministik         Kaynak / metin
  karşılaştırma         kanıt katmanı
          │                   │
          └─────────┬─────────┘
                    ▼
              Streamlit UI
                    │
                    ▼
        Chatbot / RAG (geliştiriliyor)
```

### Finansman güvenlik prensibi

Bir kullanıcı örneğin `100.000 TL / 36 ay` seçtiğinde yalnızca aynı `100.000 TL / 36 ay` koşulunda doğrulanmış sonuçlar sayısal sıralamaya girer. `100.000/24`, `50.000/18` veya ürün sayfasındaki farklı bir örnek maliyet tablosu fallback olarak kullanılmaz.

Canlı calculator sonuçlarında üç durum vardır:

- `VERIFIED`: exact tutar/vade ve temel finansal alanlar doğrulanmıştır; sıralamaya girebilir.
- `INELIGIBLE`: resmî limit/kural talep edilen senaryonun uygun olmadığını kanıtlar.
- `UNVERIFIED`: yeterli resmî kanıt yoktur; sistem sayı uydurmaz ve sıralamaya almaz.

## Dizinler

```text
Ana_Sayfa.py                         Streamlit ana giriş
pages/                               Streamlit sayfaları
src/                                 repository, kural motoru, normalizasyon, canlı sözleşme
src/finance_live_adapters/           canlı calculator adapterları
scripts/                             tarama, audit, migration ve senkronizasyon araçları
scripts/finance_scenarios/           doğrulanmış calculator scenario sync scriptleri
postgresql/schema.sql                PostgreSQL şeması
postgresql/migrations/               PostgreSQL migration dosyaları
config/                              banka/taxonomy/source ayarları
data/standard_products/              güncel standard-product JSON datasetleri
data/campaign_pages/                 resmî kaynak sayfa snapshotları
tests/                               testler
```

## Kurulum

### 1. Python ortamı

Python 3.11+ önerilir.

```powershell
python -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### 2. PostgreSQL

Yerelde `bansa_db` isimli bir PostgreSQL veritabanı oluşturun ve şemayı uygulayın:

```powershell
psql -U postgres -d bansa_db -f .\postgresql\schema.sql
```

Bağlantı bilgisi ortam değişkeni üzerinden verilir. Parolayı kaynak koduna veya Git'e yazmayın.

```powershell
$env:POSTGRES_DSN = "postgresql://USER:PASSWORD@127.0.0.1:5432/bansa_db"
```

Örnek değişkenler `.env.example` dosyasındadır.

### 3. Uygulamayı çalıştırma

Windows için güvenli launcher PostgreSQL parolasını `SecureString` ile sorar ve `.venv` varsa onu kullanır:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_streamlit_postgresql.ps1
```

Alternatif:

```powershell
python -m streamlit run .\Ana_Sayfa.py
```

## PostgreSQL veri bootstrap notu

Bu GitHub snapshot'ı **yerel PostgreSQL dump/seed ve kullanıcı parolası içermez**. `postgresql/schema.sql` yapıyı, `data/standard_products/` ve `data/campaign_pages/` ise paylaşılabilir resmî kaynak dataset/snapshotlarını içerir.

Elinizde eski `data/campaigns.db` SQLite çalışma verisi varsa PostgreSQL migration aracı kullanılabilir:

```powershell
python -X utf8 .\scripts\migrate_sqlite_to_postgresql.py --replace
```

Final yarışma tesliminde tam reproduksiyon için ayrıca güncel PostgreSQL seed/dump exportunun eklenmesi önerilir.

## Canlı finansman scenario araçları

Scriptler varsayılan olarak READ ONLY yaklaşımını korur; veritabanına yazma açıkça istenmeden yapılmamalıdır.

```powershell
python -X utf8 .\scripts\finance_scenarios\sync_emlak_katilim.py
python -X utf8 .\scripts\finance_scenarios\sync_hayat_finans.py
python -X utf8 .\scripts\finance_scenarios\sync_tom_katilim.py
```

Canlı adapterların ortak sözleşmesi:

```text
LiveCalculationRequest
        ↓
FinanceLiveAdapter.calculate(...)
        ↓
LiveCalculationResult
        ↓
VERIFIED / INELIGIBLE / UNVERIFIED
```

## Test

```powershell
python -m pytest
```

Syntax kontrolü için:

```powershell
python -m compileall -q .
```

## Güvenlik ve GitHub

Repoya dahil edilmemesi gerekenler:

- `.env`
- PostgreSQL parolaları / DSN içindeki gerçek parolalar
- yerel `.db`, `.sqlite`, `.sqlite3` dosyaları
- `backups/`
- loglar ve `__pycache__`
- tarama sırasında oluşan geçici raporlar

`.gitignore` bu dosyaları varsayılan olarak dışarıda bırakır.

## Lisans

Apache License 2.0. Ayrıntılar için `LICENSE` dosyasına bakın.

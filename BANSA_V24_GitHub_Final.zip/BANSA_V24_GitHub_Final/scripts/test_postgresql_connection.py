from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.postgres_repository import postgres_health  # noqa: E402


if __name__ == "__main__":
    result = postgres_health()
    print("PostgreSQL bağlantısı: OK")
    print("Database:", result.get("database_name"))
    print("Schema:", result.get("schema_name"))
    print("Güncel standart ürün:", result.get("current_products"))
    print("Güncel kampanya:", result.get("current_campaigns"))

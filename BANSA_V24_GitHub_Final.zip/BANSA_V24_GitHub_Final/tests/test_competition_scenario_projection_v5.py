from src.chat_followup_context import resolve_followup_question
from src.competition_fast_router import detect_banks
from src.competition_natural_chat import answer_natural
from src.finance_runtime_repository import get_standard_products
from src.finance_scenario_projection import project_row


def _row(product_id: int):
    frame = get_standard_products()
    return frame[frame["id"].eq(product_id)].iloc[0]


def test_tf_housing_500k_36_uses_official_pricing_table():
    records = project_row(_row(67), 500_000, 36)
    assert records
    assert all(r.mode == "official_pricing_table_model" for r in records)
    insured = next(r for r in records if "Sigortalı" in r.variant)
    assert insured.profit_share_rate == insured.profit_share_rate.__class__("3.58")
    assert insured.monthly_installment == insured.monthly_installment.__class__("24926.27")
    assert insured.allocation_fee == insured.allocation_fee.__class__("2500.00")


def test_vakif_housing_500k_36_uses_same_maturity_verified_calculator_projection():
    records = project_row(_row(296), 500_000, 36)
    assert records
    assert all(r.mode == "verified_same_maturity_projection" for r in records)
    rec = records[0]
    assert rec.profit_share_rate == rec.profit_share_rate.__class__("3.16")
    assert rec.monthly_installment == rec.monthly_installment.__class__("23451.90")
    assert rec.allocation_fee == rec.allocation_fee.__class__("2500.00")


def test_vehicle_projection_is_disabled_because_amount_semantics_are_asset_value_sensitive():
    # Albaraka motorcycle product: principal scaling must not bypass the vehicle rules.
    assert project_row(_row(118), 600_000, 24) == tuple()


def test_two_bank_housing_compare_calculates_requested_500k_scenario():
    result = answer_natural(
        "500.000 TL 36 ay konut finansmanında Vakıf Katılım ile Türkiye Finans karşılaştır"
    )
    assert result is not None
    assert result.route == "finance_compare"
    assert "500.000,00 TL / 36 ay" in result.text
    assert "Vakıf Katılım" in result.text
    assert "Türkiye Finans" in result.text
    assert "23.451,90 TL" in result.text
    assert "24.113,47 TL" in result.text
    assert "23.816,52 TL" in result.text
    assert "UNVERIFIED" not in result.text


def test_followup_compare_keeps_two_banks_and_uses_projection():
    history = ["Konut finansmanında Vakıf mı Türkiye Finans mı daha avantajlı?"]
    resolution = resolve_followup_question("500.000 TL 36 ay", history)
    assert resolution.used_context
    assert "Vakıf Katılım" in resolution.resolved_question
    assert "Türkiye Finans" in resolution.resolved_question
    result = answer_natural(resolution.resolved_question)
    assert result.route == "finance_compare"
    assert "23.451,90 TL" in result.text
    assert "24.113,47 TL" in result.text


def test_single_bank_tf_projection_answers_actual_amount_not_reference_only():
    result = answer_natural("Türkiye Finans 500.000 TL 36 ay konut finansmanı hesapla")
    assert result.route == "finance_scenario_projection"
    assert "500.000,00 TL / 36 ay" in result.text
    assert "24.113,47 TL" in result.text
    assert "resmî fiyatlama tablosu" in result.text


def test_single_bank_vakif_projection_answers_actual_amount_not_reference_only():
    result = answer_natural("Vakıf Katılım 500.000 TL 36 ay konut finansmanı hesapla")
    assert result.route == "finance_scenario_projection"
    assert "23.451,90 TL" in result.text
    assert "aynı vadede doğrulanmış resmî hesaplama aracı sonucu" in result.text


def test_exact_100k_36_housing_compare_stays_exact_not_projected():
    result = answer_natural("100 bin TL 36 ay vade için konut finansmanlarını kıyasla")
    assert result.route == "finance_compare"
    assert "resmî fiyatlama tablosu" in result.text
    assert "Albaraka Türk" in result.text
    assert "166.205,69 TL" in result.text


def test_turkiye_finansi_inflected_alias_is_detected():
    assert "Türkiye Finans" in detect_banks("Vakıf Katılım ile Türkiye Finansı kıyasla")

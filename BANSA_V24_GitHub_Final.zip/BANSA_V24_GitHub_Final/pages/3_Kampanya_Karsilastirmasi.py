from __future__ import annotations

import pandas as pd
import streamlit as st

from src.db import init_db
from src.repository import get_campaigns
from src.ui_display import CAMPAIGN_TYPE_LABELS, clean_campaign_title, display_text, format_number_tr
from src.ui_theme import apply_bansa_theme, render_page_header, render_section_lead, render_sidebar_navigation
from src.ui_campaign_dashboard import public_campaign_columns
from src.source_link_resolver import resolve_campaign_detail_url
from src.ui_table_density import clean_cell, display_frame_with_missing_label, fill_ratio, sanitize_frame


st.set_page_config(
    page_title="BANSA · Kampanya Karşılaştırması",
    page_icon="🎁",
    layout="wide",
    initial_sidebar_state="expanded",
)
apply_bansa_theme()
render_sidebar_navigation("campaign")

render_page_header(
    "Kampanya Karşılaştırması",
    "Kampanya türünü seçtiğiniz anda tüm bankalardaki aktif eşleşmeler tabloya gelir. Banka detayında o bankanın tüm ilgili kampanyalarını ve kampanya koşullarını inceleyebilirsiniz.",
    eyebrow="BANSA · Kampanya Dashboard'u",
)

try:
    init_db()
    campaigns = get_campaigns().copy()
except Exception:
    campaigns = pd.DataFrame()

if campaigns.empty:
    st.info("Karşılaştırılabilecek kampanya kaydı bulunmuyor.")
    st.stop()

if "is_active" in campaigns.columns:
    campaigns = campaigns[campaigns["is_active"] == 1].copy()
if campaigns.empty:
    st.info("Şu anda aktif kampanya kaydı bulunmuyor.")
    st.stop()


def _num(value: object) -> float | None:
    try:
        if value is None or pd.isna(value):
            return None
        return float(value)
    except Exception:
        return None


def _fmt(value: object, suffix: str = "") -> str:
    number = _num(value)
    if number is None:
        return "—"
    return f"{format_number_tr(number)}{suffix}"


def _category(row: pd.Series) -> str:
    campaign_type = str(row.get("campaign_type") or "").strip()
    linked = str(row.get("linked_product_type") or "").strip()
    if campaign_type == "finance_campaign" and linked:
        return linked
    return CAMPAIGN_TYPE_LABELS.get(campaign_type, campaign_type or "Diğer Kampanyalar")


def _main_benefit(row: pd.Series) -> str:
    parts: list[str] = []
    if _num(row.get("financing_amount")) is not None:
        parts.append(_fmt(row.get("financing_amount"), " TL") + " finansman")
    if _num(row.get("maturity_months")) is not None:
        parts.append(_fmt(row.get("maturity_months"), " ay"))
    if _num(row.get("installment_count")) is not None:
        parts.append(_fmt(row.get("installment_count"), " taksit"))
    if _num(row.get("discount_rate")) is not None:
        parts.append("%" + _fmt(row.get("discount_rate")) + " indirim/iade")
    if _num(row.get("shopping_points")) is not None:
        parts.append(_fmt(row.get("shopping_points")) + " puan")
    if _num(row.get("reward_amount")) is not None:
        parts.append(_fmt(row.get("reward_amount"), " TL") + " ödül")
    if _num(row.get("maximum_benefit")) is not None and not parts:
        parts.append(_fmt(row.get("maximum_benefit"), " TL") + " azami fayda")
    return " · ".join(parts[:3])


def _campaign_table(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in frame.iterrows():
        conditions = str(row.get("campaign_conditions") or "").strip()
        if len(conditions) > 520:
            conditions = conditions[:517].rstrip() + "..."
        rows.append({
            "Banka": clean_cell(display_text(row.get("bank_name"))),
            "Kampanya": clean_cell(display_text(row.get("display_name"))),
            "Tür": clean_cell(display_text(row.get("category_ui"))),
            "Ana Fayda": _main_benefit(row),
            "Hedef Kitle": clean_cell(display_text(row.get("target_audience"))),
            "Taksit": _fmt(row.get("installment_count")),
            "Vade": (_fmt(row.get("maturity_months"), " ay") if _num(row.get("maturity_months")) is not None else ""),
            "Kâr Payı": (("%" + _fmt(row.get("profit_share_rate"))) if _num(row.get("profit_share_rate")) is not None else display_text(row.get("installment_cost_text"))),
            "Finansman Tutarı": (_fmt(row.get("financing_amount"), " TL") if _num(row.get("financing_amount")) is not None else ""),
            "İndirim / İade": (("%" + _fmt(row.get("discount_rate"))) if _num(row.get("discount_rate")) is not None else ""),
            "Ödül": (_fmt(row.get("reward_amount"), " TL") if _num(row.get("reward_amount")) is not None else ""),
            "Puan": (_fmt(row.get("shopping_points")) if _num(row.get("shopping_points")) is not None else ""),
            "Min. Harcama": (_fmt(row.get("minimum_spending"), " TL") if _num(row.get("minimum_spending")) is not None else ""),
            "Maks. Fayda": (_fmt(row.get("maximum_benefit"), " TL") if _num(row.get("maximum_benefit")) is not None else ""),
            "Min. İşlem": (_fmt(row.get("minimum_transaction_amount"), " TL") if _num(row.get("minimum_transaction_amount")) is not None else ""),
            "Maks. İşlem": (_fmt(row.get("maximum_transaction_amount"), " TL") if _num(row.get("maximum_transaction_amount")) is not None else ""),
            "Başlangıç": clean_cell(display_text(row.get("campaign_start_date"))),
            "Bitiş": clean_cell(display_text(row.get("campaign_end_date"))),
            "Koşullar": clean_cell(conditions),
            "Resmî Kaynak": resolve_campaign_detail_url(
                row.get("bank_name"), row.get("display_name") or row.get("campaign_name"), row.get("source_url")
            ),
            "__id": row.get("id"),
        })
    return pd.DataFrame(rows)


campaigns["category_ui"] = campaigns.apply(_category, axis=1)
campaigns["display_name"] = campaigns.apply(
    lambda row: clean_campaign_title(row.get("campaign_name"), row.get("bank_name")), axis=1
)

render_section_lead(
    "1 · Kampanya türünü seçin",
    "Banka filtresi boşsa tüm bankalar görüntülenir. Ana tabloda seçilen türdeki tüm aktif kampanyalar yer alır; 5 kampanya sınırı yoktur.",
)

with st.container(border=True):
    f1, f2, f3 = st.columns([1.2, 1.6, 1.2])
    with f1:
        categories = ["Tümü"] + sorted(campaigns["category_ui"].dropna().astype(str).unique().tolist(), key=str.casefold)
        selected_category = st.selectbox("Kampanya türü", categories)
    with f2:
        bank_options = sorted(campaigns["bank_name"].dropna().astype(str).unique().tolist(), key=str.casefold)
        selected_banks = st.multiselect("Tablo banka filtresi", bank_options, placeholder="Boş bırakın: tüm bankalar")
    with f3:
        keyword = st.text_input("Kampanya ara", placeholder="Teknosa, akaryakıt, eğitim...")

filtered = campaigns.copy()
if selected_category != "Tümü":
    filtered = filtered[filtered["category_ui"].astype(str).eq(selected_category)].copy()
if selected_banks:
    filtered = filtered[filtered["bank_name"].astype(str).isin(selected_banks)].copy()
if keyword.strip():
    needle = keyword.strip().casefold()
    text_mask = filtered["display_name"].fillna("").astype(str).str.casefold().str.contains(needle, regex=False)
    if "campaign_conditions" in filtered:
        text_mask |= filtered["campaign_conditions"].fillna("").astype(str).str.casefold().str.contains(needle, regex=False)
    filtered = filtered[text_mask].copy()

if filtered.empty:
    st.warning("Bu filtrelerle eşleşen aktif kampanya bulunamadı.")
    st.stop()

filtered = filtered.sort_values(["bank_name", "campaign_end_date", "display_name"], kind="stable", na_position="last")
display_df = sanitize_frame(_campaign_table(filtered))

render_section_lead(
    "Tüm aktif kampanyalar",
    "Seçilen kampanya türüne göre en anlamlı ve en dolu sütunlar otomatik öne alınır. Seçili sütunlarda kaynakta bulunmayan bilgiler ‘Belirtilmedi’ olarak gösterilir; kaynak bağlantısı doğrudan kampanyanın resmî detay sayfasına gider.",
)
campaign_cols = public_campaign_columns(display_df.drop(columns=["__id"], errors="ignore"), selected_category)
main_campaign_raw = display_df[campaign_cols].copy()
main_campaign_view = display_frame_with_missing_label(main_campaign_raw, preserve_columns=("Resmî Kaynak",))
campaign_decision_cols = [c for c in campaign_cols if c not in {"Banka", "Kampanya", "Resmî Kaynak"}]
if campaign_decision_cols:
    campaign_density = sum(fill_ratio(main_campaign_raw, c) for c in campaign_decision_cols) / len(campaign_decision_cols)
else:
    campaign_density = 1.0
m1, m2, m3, m4 = st.columns(4)
m1.metric("Aktif kampanya", len(display_df))
m2.metric("Banka", display_df["Banka"].nunique())
m3.metric("Karar sütunu", len(campaign_decision_cols))
m4.metric("Tablo doluluğu", f"%{campaign_density * 100:.0f}")
st.dataframe(
    main_campaign_view,
    use_container_width=True,
    hide_index=True,
    height=min(760, 84 + 35 * max(4, len(display_df))),
    column_config={
        "Banka": st.column_config.TextColumn("Banka", width="medium"),
        "Kampanya": st.column_config.TextColumn("Kampanya", width="large"),
        "Ana Fayda": st.column_config.TextColumn("Ana Fayda", width="medium"),
        "Koşullar": st.column_config.TextColumn("Koşullar", width="large"),
        "Resmî Kaynak": st.column_config.LinkColumn("Kaynak", display_text="Aç", width="small"),
    },
)
st.download_button(
    "Kampanya tablosunu CSV indir",
    data=main_campaign_view.to_csv(index=False).encode("utf-8-sig"),
    file_name="bansa_aktif_kampanyalar.csv",
    mime="text/csv",
)

render_section_lead(
    "2 · Banka detay görünümü",
    "Bir banka seçin; seçilen kampanya türündeki tüm aktif kampanyaları ve tek tek koşullarını görün.",
)

detail_banks = sorted(filtered["bank_name"].dropna().astype(str).unique().tolist(), key=str.casefold)
detail_bank = st.selectbox("Detayını görmek istediğiniz banka", detail_banks)
bank_frame = filtered[filtered["bank_name"].astype(str).eq(detail_bank)].copy()
bank_table = sanitize_frame(_campaign_table(bank_frame))
bank_cols = public_campaign_columns(bank_table.drop(columns=["__id"], errors="ignore"), selected_category)
bank_view = display_frame_with_missing_label(bank_table[bank_cols], preserve_columns=("Resmî Kaynak",))
st.dataframe(
    bank_view,
    use_container_width=True,
    hide_index=True,
    height=min(520, 84 + 35 * max(2, len(bank_table))),
    column_config={"Resmî Kaynak": st.column_config.LinkColumn("Kaynak", display_text="Aç")},
)

campaign_names = bank_frame["display_name"].astype(str).tolist()
selected_campaign_name = st.selectbox("Kampanya detayını aç", campaign_names)
row = bank_frame[bank_frame["display_name"].astype(str).eq(selected_campaign_name)].iloc[0]
detail_pairs = [
    ("Banka", row.get("bank_name")),
    ("Kampanya", row.get("display_name")),
    ("Tür", row.get("category_ui")),
    ("Hedef Kitle", row.get("target_audience")),
    ("Taksit", _fmt(row.get("installment_count"))),
    ("Vade", _fmt(row.get("maturity_months"), " ay") if _num(row.get("maturity_months")) is not None else ""),
    ("Finansman Tutarı", _fmt(row.get("financing_amount"), " TL") if _num(row.get("financing_amount")) is not None else ""),
    ("Minimum İşlem", _fmt(row.get("minimum_transaction_amount"), " TL") if _num(row.get("minimum_transaction_amount")) is not None else ""),
    ("Maksimum İşlem", _fmt(row.get("maximum_transaction_amount"), " TL") if _num(row.get("maximum_transaction_amount")) is not None else ""),
    ("İndirim / İade", "%" + _fmt(row.get("discount_rate")) if _num(row.get("discount_rate")) is not None else ""),
    ("Ödül", _fmt(row.get("reward_amount"), " TL") if _num(row.get("reward_amount")) is not None else ""),
    ("Minimum Harcama", _fmt(row.get("minimum_spending"), " TL") if _num(row.get("minimum_spending")) is not None else ""),
    ("Maksimum Fayda", _fmt(row.get("maximum_benefit"), " TL") if _num(row.get("maximum_benefit")) is not None else ""),
    ("Başlangıç", row.get("campaign_start_date")),
    ("Bitiş", row.get("campaign_end_date")),
    ("Masraf Durumu", row.get("expense_status")),
    ("Koşullar", row.get("campaign_conditions")),
    ("Resmî Kaynak", resolve_campaign_detail_url(row.get("bank_name"), row.get("display_name") or row.get("campaign_name"), row.get("source_url"))),
]
detail_df = pd.DataFrame([
    {"Alan": label, "Doğrulanmış bilgi": clean_cell(display_text(value)) or "Belirtilmedi"}
    for label, value in detail_pairs
])
st.dataframe(detail_df, use_container_width=True, hide_index=True, height=min(620, 84 + 35 * max(3, len(detail_df))))
source_url = resolve_campaign_detail_url(row.get("bank_name"), row.get("display_name") or row.get("campaign_name"), row.get("source_url"))
if source_url:
    st.link_button("Seçili kampanyanın resmî detay sayfasını aç", source_url, use_container_width=True)

render_section_lead(
    "3 · Kritik kampanya özeti",
    "Sadece seçilen filtrede dolu olan sayısal alanlar karşılaştırılır.",
)

insights: list[tuple[str, str]] = []
rules = [
    ("installment_count", "En fazla taksit", False, " taksit"),
    ("maturity_months", "En uzun finansman vadesi", False, " ay"),
    ("discount_rate", "En yüksek indirim / iade", False, "%"),
    ("reward_amount", "En yüksek ödül", False, " TL"),
    ("maximum_benefit", "En yüksek maksimum fayda", False, " TL"),
    ("minimum_spending", "En düşük giriş harcaması", True, " TL"),
]
for column, label, ascending, suffix in rules:
    if column not in filtered.columns:
        continue
    work = filtered.copy()
    work["__value"] = pd.to_numeric(work[column], errors="coerce")
    work = work.dropna(subset=["__value"])
    if work.empty:
        continue
    best = work.sort_values("__value", ascending=ascending).iloc[0]
    value = float(best["__value"])
    value_text = format_number_tr(value)
    if suffix == "%":
        value_text = "%" + value_text
    else:
        value_text += suffix
    insights.append((label, f"{display_text(best.get('bank_name'))} · {display_text(best.get('display_name'))} — {value_text}"))

# Earliest ending active campaign is also decision-relevant.
if "campaign_end_date" in filtered.columns:
    dates = filtered.copy()
    dates["__date"] = pd.to_datetime(dates["campaign_end_date"], errors="coerce")
    dates = dates.dropna(subset=["__date"])
    if not dates.empty:
        soon = dates.sort_values("__date", ascending=True).iloc[0]
        insights.append(("En yakın bitiş tarihi", f"{display_text(soon.get('bank_name'))} · {display_text(soon.get('display_name'))} — {display_text(soon.get('campaign_end_date'))}"))

if insights:
    cols = st.columns(min(3, len(insights)))
    for idx, (label, text) in enumerate(insights[:6]):
        with cols[idx % len(cols)]:
            with st.container(border=True):
                st.caption(label)
                st.markdown(f"**{text}**")
else:
    st.info("Bu kampanya grubunda ortak sayısal kritik kriter bulunmuyor.")

with st.expander("Kampanya dashboard güvenlik kuralları"):
    st.markdown(
        """
- Yalnız **aktif** kampanyalar ana karşılaştırma tablosuna alınır.
- Seçilen türdeki **tüm eşleşen banka kampanyaları** gösterilir; rastgele ilk 5 kampanya ile sınırlandırılmaz.
- Kampanya adı/banka/topic eşleşmesi korunur; bulunamayan kampanya yerine başka kampanya kullanılmaz.
- Taksit, ödül, indirim ve tarih gibi alanlar yalnız kaynakta bulunan değerlerden gelir.
- Her kampanya satırında resmî kaynak bağlantısı tutulur.
        """
    )

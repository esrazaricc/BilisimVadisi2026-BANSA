from __future__ import annotations

import pandas as pd
import streamlit as st

from src.competition_response_service import ask_bansa
from src.ui_finance_comparison import build_finance_comparison_table
from src.ui_finance_dashboard import (
    bank_options_for_family,
    build_finance_catalog_table,
    detailed_product_record,
    finance_catalog_insights,
    finance_family_options,
    public_catalog_columns,
    scenario_insights,
)
from src.ui_theme import apply_bansa_theme, render_page_header, render_section_lead, render_sidebar_navigation
from src.ui_table_density import clean_cell, display_frame_with_missing_label, fill_ratio, sanitize_frame, select_dense_columns


st.set_page_config(
    page_title="BANSA · Finansman Karşılaştırması",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded",
)
apply_bansa_theme()
render_sidebar_navigation("finance")

render_page_header(
    "Finansman Karşılaştırması",
    "Bir finansman türü seçtiğiniz anda BANSA kapsamındaki bankaların o ailedeki tüm ürünlerini tek tabloda görün. İsterseniz tutar-vade senaryosu ekleyerek doğrulanmış güncel hesaplama sonuçlarını da karşılaştırın.",
    eyebrow="BANSA · Karar Dashboard'u",
)

family_pairs = finance_family_options()
family_labels = [label for _, label in family_pairs]
label_to_key = {label: key for key, label in family_pairs}

render_section_lead(
    "1 · Finansman türünü seçin",
    "Tablo otomatik dolar. Banka filtresi boş bırakılırsa seçilen finansman türündeki tüm bankalar ve tüm ürünler gösterilir.",
)

with st.container(border=True):
    c1, c2 = st.columns([1.3, 2.2])
    with c1:
        selected_label = st.selectbox("Finansman türü", family_labels, index=0)
    family_key = label_to_key[selected_label]
    banks_in_family = bank_options_for_family(family_key)
    with c2:
        table_bank_filter = st.multiselect(
            "Tablo banka filtresi (isteğe bağlı)",
            banks_in_family,
            placeholder="Boş bırakın: tüm bankalar",
        )

catalog = build_finance_catalog_table(family_key, table_bank_filter)
if catalog.empty:
    st.warning("Bu finansman türünde gösterilebilir ürün bulunamadı.")
    st.stop()

public_cols = public_catalog_columns(catalog, family_key)
raw_catalog = sanitize_frame(catalog[public_cols].copy())
show_catalog = display_frame_with_missing_label(raw_catalog, preserve_columns=("Ürün Kaynağı",))

decision_cols = [c for c in public_cols if c not in {"Banka", "Ürün", "Ürün Kaynağı"}]
if decision_cols:
    density = sum(fill_ratio(raw_catalog, c) for c in decision_cols) / len(decision_cols)
else:
    density = 1.0
m1, m2, m3, m4 = st.columns(4)
m1.metric("Ürün", len(show_catalog))
m2.metric("Banka", show_catalog["Banka"].nunique())
m3.metric("Karar sütunu", len(decision_cols))
m4.metric("Tablo doluluğu", f"%{density * 100:.0f}")

render_section_lead(
    "Tüm banka ve ürünler",
    "Seçilen finansman türünde doluluk oranı yüksek ve karar vermede anlamlı sütunlar otomatik seçilir. Seçili sütunlarda kaynakta bulunmayan bilgiler ‘Belirtilmedi’ olarak gösterilir; hiçbir finansal değer tahmin edilmez. Kaynak bağlantısı ürünün kendi resmî detay sayfasına gider.",
)

column_config = {
    "Banka": st.column_config.TextColumn("Banka", width="medium"),
    "Ürün": st.column_config.TextColumn("Ürün", width="large"),
    "Ürün Kaynağı": st.column_config.LinkColumn("Ürün Kaynağı", display_text="Aç", width="small"),
    "Kâr Payı / Fiyatlama": st.column_config.TextColumn("Kâr Payı / Fiyatlama", width="large"),
    "Limit / Finansman Tutarı": st.column_config.TextColumn("Limit / Tutar", width="medium"),
    "Vade / Ödeme": st.column_config.TextColumn("Vade / Ödeme", width="large"),
    "Finansman Oranı / Kuralı": st.column_config.TextColumn("Finansman Oranı / Kuralı", width="large"),
    "Hesaplama Aracı": st.column_config.TextColumn("Hesaplama Aracı", width="large"),
    "Kullanım Amacı": st.column_config.TextColumn("Kullanım Amacı", width="large"),
    "Finansman Yapısı": st.column_config.TextColumn("Finansman Yapısı", width="large"),
    "Ödeme / Kullanım": st.column_config.TextColumn("Ödeme / Kullanım", width="large"),
    "Özel Koşullar": st.column_config.TextColumn("Özel Koşullar", width="large"),
}

st.dataframe(
    show_catalog,
    use_container_width=True,
    hide_index=True,
    height=min(760, 84 + 35 * max(4, len(show_catalog))),
    column_config=column_config,
)
st.download_button(
    "Tüm ürün tablosunu CSV indir",
    data=show_catalog.to_csv(index=False).encode("utf-8-sig"),
    file_name=f"bansa_{family_key}_tum_urunler.csv",
    mime="text/csv",
)

render_section_lead(
    "2 · Tutar / vade senaryosu (isteğe bağlı)",
    "Aynı finansman tutarı ve vadede güncel sayısal sonucu doğrulanabilen bankaları karşılaştırır. Sonuç yoksa eski snapshot ile sayı uydurulmaz.",
)

if "bansa_v22_scenario_answer" not in st.session_state:
    st.session_state["bansa_v22_scenario_answer"] = ""
if "bansa_v22_scenario_ctx" not in st.session_state:
    st.session_state["bansa_v22_scenario_ctx"] = {}

with st.container(border=True):
    enabled = st.toggle("Senaryo hesabını aç", value=False)
    if enabled:
        s1, s2, s3 = st.columns([1, 1, 2])
        with s1:
            amount = st.number_input("Finansman tutarı (TL)", min_value=1_000, max_value=100_000_000, value=100_000, step=10_000)
        with s2:
            maturity = st.number_input("Vade (ay)", min_value=1, max_value=240, value=36, step=1)
        with s3:
            scenario_banks = st.multiselect(
                "Senaryoda karşılaştırılacak bankalar",
                banks_in_family,
                default=table_bank_filter,
                placeholder="Boş bırakın: uygun tüm bankalar",
            )

        if st.button("Güncel senaryoyu karşılaştır", type="primary", use_container_width=True):
            bank_phrase = ""
            if scenario_banks:
                if len(scenario_banks) == 1:
                    bank_phrase = f"{scenario_banks[0]} için "
                elif len(scenario_banks) == 2:
                    bank_phrase = f"{scenario_banks[0]} ile {scenario_banks[1]} arasında "
                else:
                    bank_phrase = ", ".join(scenario_banks[:-1]) + f" ve {scenario_banks[-1]} arasında "
            question = f"{int(amount)} TL {int(maturity)} ay {bank_phrase}{selected_label.lower()} seçeneklerini karşılaştır"
            with st.spinner("Resmî hesaplama/fiyatlama sonuçları doğrulanıyor..."):
                try:
                    response = ask_bansa(question)
                    answer = str(getattr(response, "text", "") or "").strip()
                except Exception:
                    answer = ""
            st.session_state["bansa_v22_scenario_answer"] = answer or "Bu senaryoda doğrulanmış sayısal sonuç üretilemedi."
            st.session_state["bansa_v22_scenario_ctx"] = {
                "amount": float(amount), "maturity": int(maturity), "banks": list(scenario_banks), "label": selected_label
            }

scenario_answer = st.session_state.get("bansa_v22_scenario_answer", "")
scenario_ctx = st.session_state.get("bansa_v22_scenario_ctx", {})
scenario_table = pd.DataFrame()
if scenario_answer:
    render_section_lead("Doğrulanmış senaryo sonuçları")
    try:
        scenario_table = build_finance_comparison_table(
            scenario_answer,
            product_label=str(scenario_ctx.get("label") or selected_label),
            amount=float(scenario_ctx.get("amount") or 0),
            selected_banks=list(scenario_ctx.get("banks") or []),
        )
    except Exception:
        scenario_table = pd.DataFrame()
    if not scenario_table.empty:
        scenario_table = sanitize_frame(scenario_table)
        scenario_preferred = (
            "Koşul", "Kâr Payı", "Aylık Taksit", "Toplam Geri Ödeme", "Durum",
            "Vade / Vade Bantları", "Finansman Oranı / Kuralı", "Finansman Tutar Limiti",
            "Hesaplama Aracı Sınırı", "Tahsis Ücreti", "Ekspertiz", "İpotek / Rehin",
            "Toplam Masraf", "Özel Koşul", "Kaynak Türü",
        )
        scenario_cols = select_dense_columns(
            scenario_table,
            preferred=scenario_preferred,
            mandatory=("Banka", "Ürün"),
            trailing=("Resmî Kaynak",),
            min_fill=0.20,
            min_optional=6,
            max_optional=12,
        )
        scenario_view = display_frame_with_missing_label(
            scenario_table[scenario_cols], preserve_columns=("Resmî Kaynak",)
        )
        st.dataframe(
            scenario_view,
            use_container_width=True,
            hide_index=True,
            height=min(650, 84 + 36 * max(3, len(scenario_table))),
            column_config={"Resmî Kaynak": st.column_config.LinkColumn("Kaynak", display_text="Aç")},
        )
    with st.expander("BANSA'nın doğal senaryo yorumu", expanded=False):
        st.markdown(scenario_answer)

render_section_lead(
    "3 · Banka detay görünümü",
    "Bir banka seçtiğinizde bu finansman türündeki tüm ürünlerini ve seçtiğiniz ürüne ait doğrulanmış detayları aşağıda görebilirsiniz.",
)

detail_bank = st.selectbox("Detayını görmek istediğiniz banka", banks_in_family, index=0)
bank_catalog = build_finance_catalog_table(family_key, [detail_bank])
if not bank_catalog.empty:
    bank_public_cols = public_catalog_columns(bank_catalog, family_key)
    bank_view = display_frame_with_missing_label(bank_catalog[bank_public_cols], preserve_columns=("Ürün Kaynağı",))
    st.dataframe(
        bank_view,
        use_container_width=True,
        hide_index=True,
        height=min(520, 84 + 35 * max(2, len(bank_catalog))),
        column_config=column_config,
    )

    options = [f"{row['Ürün']}  ·  #{row['__product_id']}" for _, row in bank_catalog.iterrows()]
    selected_product_option = st.selectbox("Ürün detayını aç", options)
    selected_id = selected_product_option.rsplit("#", 1)[-1]
    details = detailed_product_record(selected_id)
    if details:
        detail_rows = [
            {"Alan": k, "Doğrulanmış bilgi": clean_cell(v) or "Belirtilmedi"}
            for k, v in details.items()
        ]
        detail_df = pd.DataFrame(detail_rows)
        st.dataframe(
            detail_df,
            use_container_width=True,
            hide_index=True,
            height=min(620, 84 + 35 * max(3, len(detail_df))),
            column_config={"Doğrulanmış bilgi": st.column_config.TextColumn("Doğrulanmış bilgi", width="large")},
        )
        product_source = str(details.get("Ürün Kaynağı") or "").strip()
        if product_source:
            st.link_button("Seçili finansman ürününün resmî detay sayfasını aç", product_source, use_container_width=True)

render_section_lead(
    "4 · Kritik karar özeti",
    "Yalnız tabloda gerçekten bulunan karşılaştırılabilir sayısal alanlardan üretilir.",
)

insights = []
if not scenario_table.empty:
    insights.extend(scenario_insights(scenario_table))
insights.extend(finance_catalog_insights(catalog))
# Keep unique labels, scenario insights first.
seen = set()
insights = [item for item in insights if not (item[0] in seen or seen.add(item[0]))][:6]
if insights:
    cols = st.columns(min(3, len(insights)))
    for i, (label, text) in enumerate(insights):
        with cols[i % len(cols)]:
            with st.container(border=True):
                st.caption(label)
                st.markdown(f"**{text}**")
else:
    st.info("Bu finansman türünde ortak sayısal kritik kriter bulunmuyor.")

with st.expander("BANSA bu dashboard'u nasıl güvenli tutuyor?"):
    st.markdown(
        """
- Finansman türü seçildiğinde **tek bir örnek ürün değil, o ailedeki tüm banka ürünleri** gösterilir.
- Tutar/vade senaryosunda **calculator-first** ve güncel resmî fiyatlama önceliği uygulanır.
- Başka tutardaki eski örnek kullanıcı senaryosuna ölçeklenmez.
- Kaynakta bulunmayan oran, taksit veya masraf tahmin edilmez.
- Dünya Katılım taşıt kaynağındaki tutar bantları **yalnız vade** için kullanılır; `%50 → 300 bin TL` gibi bir oran türetilmez.
- Hesaplama aracındaki giriş üst sınırı, ürünün kesin finansman politikasıyla karıştırılmaz.
        """
    )

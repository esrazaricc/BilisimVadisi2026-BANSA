"""Deterministic scenario projection from verified BANSA finance evidence.

Purpose
-------
The strict verified resolver only returns a numeric result when the *exact*
amount/maturity was previously verified.  For jury-facing Q&A this can be too
rigid even when BANSA already owns trustworthy evidence for the same product:

* an official published pricing table for the requested maturity, or
* a verified official-calculator result for the same maturity at another
  principal amount.

This module provides a deliberately conservative second tier.  It never
changes the observed profit-share rate and never interpolates between
maturities.  It can only:

1. return an exact verified scenario;
2. reuse an official table rate for the exact requested maturity and calculate
   the standard annuity payment; or
3. scale a verified calculator payment from the *same maturity* to a different
   principal amount (payment is linear in principal when the rate/maturity are
   unchanged).

Projected results are explicitly labelled and are never represented as a live
bank quote.  Product fee rules remain authoritative; scenario-only fees are
not blindly scaled.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP, getcontext
import json
from typing import Iterable

import pandas as pd

from src.finance_runtime_repository import get_verified_finance_scenarios

getcontext().prec = 34


@dataclass(frozen=True)
class ScenarioProjection:
    bank_name: str
    product_name: str
    variant: str
    amount: Decimal
    maturity_months: int
    profit_share_rate: Decimal
    monthly_installment: Decimal
    installment_total: Decimal
    mode: str
    source_kind: str
    source_url: str
    checked_at: str
    base_amount: Decimal | None = None
    base_monthly_installment: Decimal | None = None
    allocation_fee: Decimal | None = None
    allocation_fee_rate: Decimal | None = None
    appraisal_fee: Decimal | None = None
    mortgage_fee: Decimal | None = None
    fee_note: str = ""

    @property
    def exact(self) -> bool:
        return self.mode == "exact_verified"

    @property
    def projected(self) -> bool:
        return not self.exact


def _d(value) -> Decimal | None:
    if value is None:
        return None
    try:
        if bool(pd.isna(value)):
            return None
    except Exception:
        pass
    text = str(value).strip()
    if not text or text.casefold() in {"nan", "none"}:
        return None
    try:
        return Decimal(text)
    except Exception:
        return None


def _money(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def _rules(row) -> dict:
    raw = row.get("finance_rules_json")
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str) and raw.strip():
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def _fee_policy(row, amount: Decimal) -> tuple[Decimal | None, Decimal | None, Decimal | None, Decimal | None, str]:
    """Return authoritative product fee information for this amount.

    The allocation fee is calculable when the official rule is percentage
    based.  Third-party appraisal/mortgage amounts are kept as published
    reference/minimum amounts, not scaled with the financing principal.
    """
    allocation = None
    allocation_rate = None
    appraisal = None
    mortgage = None
    notes: list[str] = []

    for fee in _rules(row).get("fee_rules", []) or []:
        if not isinstance(fee, dict):
            continue
        fee_type = str(fee.get("fee_type") or "").strip().casefold()
        waived = bool(fee.get("waived"))
        rate = _d(fee.get("rate"))
        fixed = _d(fee.get("amount"))
        note = str(fee.get("note") or "").strip()

        if fee_type == "allocation":
            if waived:
                allocation = Decimal("0.00")
            elif rate is not None:
                allocation_rate = rate
                allocation = _money(amount * rate / Decimal("100"))
            elif fixed is not None:
                allocation = _money(fixed)
            if note:
                notes.append("Tahsis: " + note)
        elif fee_type == "appraisal" and fixed is not None:
            appraisal = _money(fixed)
            if note:
                notes.append("Ekspertiz: " + note)
        elif fee_type in {"mortgage_establishment", "mortgage", "pledge"} and fixed is not None:
            mortgage = _money(fixed)
            if note:
                notes.append("İpotek: " + note)

    return allocation, allocation_rate, appraisal, mortgage, " | ".join(notes)


def _published_tiers(row, maturity: int) -> list[dict]:
    tiers = []
    for tier in _rules(row).get("pricing_tiers", []) or []:
        if not isinstance(tier, dict):
            continue
        try:
            tier_maturity = int(tier.get("maturity_months"))
        except Exception:
            continue
        if tier_maturity != int(maturity):
            continue
        rate = _d(tier.get("profit_share_rate"))
        if rate is None or rate <= 0:
            continue
        tiers.append(tier)
    return tiers


def _annuity(amount: Decimal, monthly_rate_percent: Decimal, maturity: int) -> Decimal:
    r = monthly_rate_percent / Decimal("100")
    n = int(maturity)
    if r == 0:
        return _money(amount / Decimal(n))
    factor = (Decimal("1") + r) ** n
    monthly = amount * (r * factor) / (factor - Decimal("1"))
    return _money(monthly)


def _safe_variant(value) -> str:
    text = str(value or "standard").strip()
    return text if text and text.casefold() not in {"nan", "none"} else "standard"


def _ts(value):
    try:
        if value is None or str(value).strip() == "":
            return None
        return pd.to_datetime(value, utc=True, errors="coerce")
    except Exception:
        return None


def _tiers_are_fresher_than_exact(tiers: list[dict], exact: pd.DataFrame) -> bool:
    """Prefer a newer official pricing table over an older calculator snapshot.

    Competition overlays carry verified_checked_at on every published pricing
    tier.  Historical exact scenarios stay useful, but must not silently
    override a newer official table after a bank changes its rates.
    """
    if not tiers or exact is None or exact.empty:
        return False
    tier_times = [_ts(t.get("verified_checked_at") or t.get("checked_at")) for t in tiers]
    tier_times = [t for t in tier_times if t is not None and not pd.isna(t)]
    exact_times = [_ts(v) for v in exact.get("checked_at", pd.Series(dtype=object)).tolist()]
    exact_times = [t for t in exact_times if t is not None and not pd.isna(t)]
    if not tier_times:
        return False
    if not exact_times:
        return True
    return max(tier_times) > max(exact_times)


def _tier_projections(row, amount_d: Decimal, maturity: int, tiers: list[dict],
                      allocation, allocation_rate, appraisal, mortgage, fee_note) -> tuple[ScenarioProjection, ...]:
    out = []
    for tier in tiers:
        rate = _d(tier.get("profit_share_rate"))
        if rate is None:
            continue
        monthly = _annuity(amount_d, rate, int(maturity))
        out.append(ScenarioProjection(
            bank_name=str(row.get("bank_name")),
            product_name=str(row.get("product_name")),
            variant=_safe_variant(tier.get("pricing_variant")),
            amount=amount_d,
            maturity_months=int(maturity),
            profit_share_rate=rate,
            monthly_installment=monthly,
            installment_total=_money(monthly * Decimal(int(maturity))),
            mode="official_pricing_table_model",
            source_kind=str(tier.get("source_type") or "official_pricing_table"),
            source_url=str(tier.get("source_url") or row.get("source_url") or row.get("url") or ""),
            checked_at=str(tier.get("verified_checked_at") or row.get("last_checked_at") or row.get("checked_at") or ""),
            allocation_fee=allocation,
            allocation_fee_rate=allocation_rate,
            appraisal_fee=appraisal,
            mortgage_fee=mortgage,
            fee_note=fee_note,
        ))
    return tuple(out)


def project_row(row, amount, maturity: int) -> tuple[ScenarioProjection, ...]:
    amount_d = _d(amount)
    if amount_d is None or amount_d <= 0 or int(maturity) <= 0:
        return tuple()

    family_key = str(row.get("product_family_key") or "").strip().casefold()

    # Vehicle queries can safely use an *official published pricing table* for
    # the requested finance principal, but must never scale an old calculator
    # snapshot because a number in a vehicle conversation may instead be the
    # asset/kasko value.  Housing keeps the full exact/table/same-term cascade.
    if family_key not in {"konut_finansmani", "arac_finansmani"}:
        return tuple()

    if family_key == "arac_finansmani":
        # V15: eligibility/pricing tables do NOT prove the bank's payment
        # formula. We observed that a generic annuity projection from a current
        # published rate can disagree with the bank's official calculator.
        # Therefore vehicle monthly/total values require an exact calculator
        # result (handled by live-first comparison) or a rate-confirmed exact
        # calculator snapshot. Static tiers remain rate evidence only.
        return tuple()

    product_id = int(row.get("id"))
    scenarios = get_verified_finance_scenarios()
    work = scenarios[scenarios["product_id"].eq(product_id)].copy()
    if not work.empty:
        status = work["scenario_status"].astype(str).str.casefold()
        work = work[status.str.contains("verified", na=False)].copy()

        # V16 FRESH-DYNAMIC-SNAPSHOT GATE
        #
        # A calculator snapshot is not a published price list.  When a bank
        # exposes only a dynamic calculator (Albaraka housing is the important
        # case), old same-maturity rows must not be scaled indefinitely and
        # presented as current pricing.  Keep calculator snapshots for at most
        # 72 hours unless a current official pricing tier independently owns
        # the requested term later in this function.
        if not work.empty and "checked_at" in work.columns:
            source_kind = (
                work.get("source_kind", pd.Series("", index=work.index))
                .fillna("")
                .astype(str)
                .str.casefold()
            )
            scenario_status = (
                work.get("scenario_status", pd.Series("", index=work.index))
                .fillna("")
                .astype(str)
                .str.casefold()
            )
            dynamic = (
                source_kind.eq("official_live_calculator_endpoint")
                | scenario_status.str.contains("live_calculator", na=False)
            )
            checked = pd.to_datetime(work["checked_at"], utc=True, errors="coerce")
            now = pd.Timestamp.now(tz="UTC")
            fresh = checked.notna() & ((now - checked) <= pd.Timedelta(hours=72))
            work = work[(~dynamic) | fresh].copy()

    allocation, allocation_rate, appraisal, mortgage, fee_note = _fee_policy(row, amount_d)
    tiers = _published_tiers(row, int(maturity))

    # Exact snapshots remain strongest only while they are at least as fresh as
    # the currently published official pricing table.  If the bank has changed
    # its rate table since that snapshot, the newer official table owns the
    # scenario instead of serving stale numbers to the jury.
    exact = pd.DataFrame()
    if not work.empty:
        exact = work[
            pd.to_numeric(work["input_maturity_months"], errors="coerce").eq(int(maturity))
            & pd.to_numeric(work["input_amount"], errors="coerce").eq(float(amount_d))
        ].copy()

    if _tiers_are_fresher_than_exact(tiers, exact):
        fresh = _tier_projections(
            row, amount_d, int(maturity), tiers,
            allocation, allocation_rate, appraisal, mortgage, fee_note,
        )
        if fresh:
            return fresh

    # Tier 1: exact amount + maturity, preserving original verified numbers.
    if not exact.empty:
        out = []
        for _, s in exact.iterrows():
            rate = _d(s.get("profit_share_rate"))
            monthly = _d(s.get("monthly_installment"))
            total = _d(s.get("total_repayment"))
            if rate is None or monthly is None or total is None:
                continue
            out.append(ScenarioProjection(
                bank_name=str(row.get("bank_name")),
                product_name=str(row.get("product_name")),
                variant=_safe_variant(s.get("input_variant")),
                amount=amount_d,
                maturity_months=int(maturity),
                profit_share_rate=rate,
                monthly_installment=_money(monthly),
                installment_total=_money(total),
                mode="exact_verified",
                source_kind=str(s.get("source_kind") or "verified_calculator_snapshot"),
                source_url=str(s.get("source_url") or row.get("source_url") or row.get("url") or ""),
                checked_at=str(s.get("checked_at") or ""),
                allocation_fee=_d(s.get("allocation_fee")) or allocation,
                allocation_fee_rate=allocation_rate,
                appraisal_fee=_d(s.get("appraisal_fee")) or appraisal,
                mortgage_fee=_d(s.get("mortgage_fee")) or mortgage,
                fee_note=fee_note,
            ))
        if out:
            return tuple(out)

    # Tier 2: official pricing table for this exact maturity. No maturity/rate
    # interpolation is allowed. Each published variant remains separate.
    if tiers:
        published = _tier_projections(
            row, amount_d, int(maturity), tiers,
            allocation, allocation_rate, appraisal, mortgage, fee_note,
        )
        if published:
            return published

    # Tier 3: verified official-calculator result at the SAME maturity.
    # We do not reuse a rate across maturities.  Scaling principal/payment is
    # mathematically linear for an unchanged rate and term; the answer is
    # clearly labelled as a BANSA scenario projection, not a live quote.
    if not work.empty:
        same_maturity = work[
            pd.to_numeric(work["input_maturity_months"], errors="coerce").eq(int(maturity))
        ].copy()
        if not same_maturity.empty:
            out = []
            for _, s in same_maturity.iterrows():
                base_amount = _d(s.get("input_amount"))
                base_monthly = _d(s.get("monthly_installment"))
                rate = _d(s.get("profit_share_rate"))
                if base_amount is None or base_amount <= 0 or base_monthly is None or rate is None:
                    continue
                ratio = amount_d / base_amount
                monthly = _money(base_monthly * ratio)
                total = _money(monthly * Decimal(int(maturity)))
                out.append(ScenarioProjection(
                    bank_name=str(row.get("bank_name")),
                    product_name=str(row.get("product_name")),
                    variant=_safe_variant(s.get("input_variant")),
                    amount=amount_d,
                    maturity_months=int(maturity),
                    profit_share_rate=rate,
                    monthly_installment=monthly,
                    installment_total=total,
                    mode="verified_same_maturity_projection",
                    source_kind=str(s.get("source_kind") or "verified_calculator_snapshot"),
                    source_url=str(s.get("source_url") or row.get("source_url") or row.get("url") or ""),
                    checked_at=str(s.get("checked_at") or ""),
                    base_amount=base_amount,
                    base_monthly_installment=base_monthly,
                    allocation_fee=allocation,
                    allocation_fee_rate=allocation_rate,
                    appraisal_fee=appraisal,
                    mortgage_fee=mortgage,
                    fee_note=fee_note,
                ))
            if out:
                return tuple(out)

    return tuple()


def project_rows(rows: Iterable, amount, maturity: int) -> dict[str, tuple[ScenarioProjection, ...]]:
    out: dict[str, tuple[ScenarioProjection, ...]] = {}
    for row in rows:
        records = project_row(row, amount, maturity)
        if records:
            out[str(row.get("bank_name"))] = records
    return out
